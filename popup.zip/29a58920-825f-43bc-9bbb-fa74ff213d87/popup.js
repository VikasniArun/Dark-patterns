chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    var tab = tabs[0];
    const newUrl = tab.url;
  
    // Function to detect if the length of the URL exceeds a certain threshold
function longUrlDetectedFromUrl(url) {
    try {
        const parsedUrl = new URL(url);
        if (parsedUrl.href.length > 100) {  // Adjust threshold as needed
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error("Error detecting long URL from", url, ":", e);
        return false;
    }
}

// Function to detect if the URL contains a numeric IP address
function numericIpDetectedFromUrl(url) {
    try {
        const domain = new URL(url).hostname;
        if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(domain)) {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error("Error detecting numeric IP from", url, ":", e);
        return false;
    }
}

// Function to detect if there are too many subdomains in the URL
function excessiveSubdomainsDetectedFromUrl(url) {
    try {
        const domain = new URL(url).hostname;
        const subdomains = domain.split('.');
        if (subdomains.length > 4) {  // Adjust threshold as needed
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error("Error detecting excessive subdomains from", url, ":", e);
        return false;
    }
}

// Function to detect if there is URL redirection
async function redirectionDetectedFromUrl(url) {
    try {
        const response = await fetch(url, { redirect: 'manual' });
        if ([301, 302, 303, 307, 308].includes(response.status)) {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error("Error detecting redirection from", url, ":", e);
        return false;
    }
}

// Function to detect if an IP address is used in the domain part of the URL
function ipInDomainDetectedFromUrl(url) {
    try {
        const domain = new URL(url).hostname;
        if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(domain)) {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error("Error detecting IP address in domain from", url, ":", e);
        return false;
    }
}

// Function to detect suspicious top-level domains
function suspiciousTldDetectedFromUrl(url) {
    const suspiciousTlds = ['.top', '.xyz', '.info', '.club', '.online'];  // Add more if needed
    try {
        const domain = new URL(url).hostname;
        if (suspiciousTlds.some(tld => domain.endsWith(tld))) {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error("Error detecting suspicious TLD from", url, ":", e);
        return false;
    }
}

// Function to detect URL shortening services
function urlShorteningServiceDetectedFromUrl(url) {
    const urlShorteners = ['bit.ly', 'goo.gl', 'tinyurl.com', 'ow.ly'];  // Add more if needed
    try {
        const domain = new URL(url).hostname;
        if (urlShorteners.includes(domain)) {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error("Error detecting URL shortening service from", url, ":", e);
        return false;
    }
}

// Function to detect suspicious characters in URL
function suspiciousCharactersDetectedFromUrl(url) {
    try {
        if (/[^\w\d\-./:]/.test(url)) {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error("Error detecting suspicious characters from", url, ":", e);
        return false;
    }
}

// Function to detect if HTTPS is not used
function noHttpsDetectedFromUrl(url) {
    try {
        const protocol = new URL(url).protocol;
        if (protocol !== 'https:') {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error("Error detecting HTTPS usage from", url, ":", e);
        return false;
    }
}

// Function to detect known spam domains or URLs
function knownSpamDetectedFromUrl(url) {
    const knownSpamDomains = ['spamdomain.com', 'phishingurl.org', 'malicious.site'];  // Add more if needed
    try {
        const domain = new URL(url).hostname;
        if (knownSpamDomains.includes(domain)) {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error("Error detecting known spam from", url, ":", e);
        return false;
    }
}

    async function detectDarkPatternsFromUrl(url) {
      try {
        const results = [
          ['long_url_detected', longUrlDetectedFromUrl(url)],
          ['numeric_ip_detected', numericIpDetectedFromUrl(url)],
          ['excessive_subdomains_detected', excessiveSubdomainsDetectedFromUrl(url)],
          ['redirection_detected', await redirectionDetectedFromUrl(url)],
          ['ip_in_domain_detected', ipInDomainDetectedFromUrl(url)],
          ['suspicious_tld_detected', suspiciousTldDetectedFromUrl(url)],
          ['url_shortening_service_detected', urlShorteningServiceDetectedFromUrl(url)],
          ['suspicious_characters_detected', suspiciousCharactersDetectedFromUrl(url)],
          // Add other detection functions here
        ];
        return results;
      } catch (e) {
        console.error("Error detecting dark patterns from", url, ":", e);
        return [];
      }
    }
function highlightRandomPlaces() {
    const highlightedElements = [];

    // Define highlighting style
    const highlightStyle = 'background-color: yellow;';

    // Function to apply highlight style to an element
    const applyHighlight = element => {
        element.style.cssText += highlightStyle;
        highlightedElements.push(element);
    };

    // Function to remove highlighting from elements
    const removeHighlight = element => {
        element.style.removeProperty('background-color');
        highlightedElements.splice(highlightedElements.indexOf(element), 1);
    };

    // Function to generate a random number within a range
    const getRandomNumber = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

    // Randomly select three different elements on the page and highlight them
    while (highlightedElements.length < 3) {
        const allElements = document.querySelectorAll('*');
        const randomIndex = getRandomNumber(0, allElements.length - 1);
        const randomElement = allElements[randomIndex];

        // Check if the element is already highlighted
        if (!highlightedElements.includes(randomElement)) {
            applyHighlight(randomElement);
        }
    }

    // Optional: Remove highlighting after a certain time (e.g., 5 seconds)
    setTimeout(() => {
        highlightedElements.forEach(removeHighlight);
    }, 5000); // Adjust the time as needed
}

// Call the function to highlight random places on the webpage
highlightRandomPlaces();



// Example usage:
detectDarkPatternsFromUrl(newUrl)
  .then(results => {
    displayResults(results);
  })
  .catch(error => {
    console.error("Error:", error);
  });
  
    // Function to display results in the popup
    function displayResults(results) {
      var resultsContainer = document.getElementById('results');
      resultsContainer.innerHTML = ''; // Clear previous results
  
      results.forEach(result => {
        var resultElement = document.createElement('div');
        resultElement.textContent = `${result[0]}: ${result[1]}`;
        resultsContainer.appendChild(resultElement);
      });
    }
  
    // Example usage:
    detectDarkPatternsFromUrl(newUrl)
      .then(results => {
        displayResults(results);
      })
      .catch(error => {
        console.error("Error:", error);
      });
});
