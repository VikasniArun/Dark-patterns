import requests
from bs4 import BeautifulSoup
import re

# Function to extract text content from a website URL
def extract_text_from_url(url):
    try:
        response = requests.get(url, verify=False)  # Disable SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        # Extract text from HTML content
        text = ' '.join([element.get_text(separator=' ') for element in soup.find_all(['p', 'span', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'])])
        return text
    except Exception as e:
        print("Error extracting text from", url, ":", e)
        return ""

# Function to detect popups
def popups_detected(url):
    try:
        response = requests.get(url, verify=False)  # Disable SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        if soup.find_all('div', class_=re.compile(r'popup|modal')):
            return True
        else:
            return False
    except Exception as e:
        print("Error detecting popups on", url, ":", e)
        return False

# Function to detect hidden elements
def hidden_elements_detected(url):
    try:
        response = requests.get(url, verify=False)  # Disable SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        if soup.find_all(style=re.compile(r'display:\s*none')):
            return True
        else:
            return False
    except Exception as e:
        print("Error detecting hidden elements on", url, ":", e)
        return False

# Function to detect suspicious buttons
def suspicious_buttons_detected(url):
    try:
        response = requests.get(url, verify=False)  # Disable SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        if soup.find_all('button', class_=re.compile(r'buy-now|claim-now|urgent|limited-time')):
            return True
        else:
            return False
    except Exception as e:
        print("Error detecting suspicious buttons on", url, ":", e)
        return False

# Function to detect misleading elements
def misleading_elements_detected(url):
    try:
        response = requests.get(url, verify=False)  # Disable SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        if soup.find_all(string=re.compile(r'[^\.!?]\b(?:misleading|fake|scam|fraud|deceptive)\b[^\.!?]', flags=re.IGNORECASE)):
            return True
        else:
            return False
    except Exception as e:
        print("Error detecting misleading elements on", url, ":", e)
        return False

# Function to detect hidden fees
def hidden_fees_detected(url):
    try:
        response = requests.get(url, verify=False)  # Disable SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        if soup.find_all(string=re.compile(r'[^\.!?]\b(?:hidden fee|extra charge|additional cost)\b[^\.!?]', flags=re.IGNORECASE)):
            return True
        else:
            return False
    except Exception as e:
        print("Error detecting hidden fees on", url, ":", e)
        return False

# Function to detect forced continuity
def forced_continuity_detected(url):
    try:
        response = requests.get(url, verify=False)  # Disable SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        if soup.find_all(string=re.compile(r'[^\.!?]\b(?:forced continuity|subscription trap)\b[^\.!?]', flags=re.IGNORECASE)):
            return True
        else:
            return False
    except Exception as e:
        print("Error detecting forced continuity on", url, ":", e)
        return False

# Function to detect aggressive timers
def aggressive_timers_detected(url):
    try:
        response = requests.get(url, verify=False)  # Disable SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        if soup.find_all('div', class_=re.compile(r'timer|countdown')):
            return True
        else:
            return False
    except Exception as e:
        print("Error detecting aggressive timers on", url, ":", e)
        return False

# Function to detect social proof manipulation
def social_proof_manipulation_detected(url):
    try:
        response = requests.get(url, verify=False)  # Disable SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        if soup.find_all(string=re.compile(r'[^\.!?]\b(?:only [0-9]+ left|selling fast|high demand)\b[^\.!?]', flags=re.IGNORECASE)):
            return True
        else:
            return False
    except Exception as e:
        print("Error detecting social proof manipulation on", url, ":", e)
        return False

# Function to detect misdirection
def misdirection_detected(url):
    try:
        response = requests.get(url, verify=False)  # Disable SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        if soup.find_all(string=re.compile(r'[^\.!?]\b(?:click here|hidden link|deceptive redirect|misleading link)\b[^\.!?]', flags=re.IGNORECASE)):
            return True
        else:
            return False
    except Exception as e:
        print("Error detecting misdirection on", url, ":", e)
        return False

# Function to detect difficulty unsubscribing
def difficulty_unsubscribing_detected(url):
    try:
        response = requests.get(url, verify=False)  # Disable SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        if soup.find_all(string=re.compile(r'[^\.!?]\b(?:unsubscribe|opt out|remove me|cancel subscription)\b[^\.!?]', flags=re.IGNORECASE)):
            return True
        else:
            return False
    except Exception as e:
        print("Error detecting difficulty unsubscribing on", url, ":", e)
        return False

# Function to detect hidden terms and conditions
def hidden_terms_conditions_detected(url):
    try:
        response = requests.get(url, verify=False)  # Disable SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        if soup.find_all(string=re.compile(r'[^\.!?]\b(?:hidden terms and conditions|fine print)\b[^\.!?]', flags=re.IGNORECASE)):
            return True
        else:
            return False
    except Exception as e:
        print("Error detecting hidden terms and conditions on", url, ":", e)
        return False

# Function to detect trick questions
def trick_questions_detected(url):
    try:
        response = requests.get(url, verify=False)  # Disable SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        if soup.find_all(string=re.compile(r'[^\.!?]\b(?:trick question|deceptive question)\b[^\.!?]', flags=re.IGNORECASE)):
            return True
        else:
            return False
    except Exception as e:
                print("Error detecting trick questions on", url, ":", e)