import requests
import nltk
from bs4 import BeautifulSoup
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from joblib import Parallel, delayed

# Function to extract text content from a website URL
def extract_text_from_url(url):
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        # Extract text from HTML content
        text = ' '.join([element.text for element in soup.find_all('p')])  # Extract text from paragraphs
        return text
    except Exception as e:
        print("Error:", e)
        return ""

# Define a function to be executed in parallel
def process_url(url):
    # Process the URL here
    result = extract_text_from_url(url)  # Example: Extracting text from the URL
    return result

# List of URLs to process
urls = [...]

# Execute tasks in parallel using joblib
results = Parallel(n_jobs=-1)(delayed(process_url)(url) for url in urls)

# Function to preprocess text
def preprocess_text(text):
    # Tokenize text
    tokens = word_tokenize(text.lower())  # Convert to lowercase and tokenize
    # Remove stopwords and non-alphabetic tokens
    stop_words = set(stopwords.words('english'))
    filtered_tokens = [token for token in tokens if token.isalpha() and token not in stop_words]
    # Convert tokens back to string
    preprocessed_text = ' '.join(filtered_tokens)
    return preprocessed_text

# Example dataset of websites labeled with dark pattern presence (1) or absence (0)
# You should replace this with your own labeled dataset
websites = [
    ("https://www.amazon.com/", 1),
    ("https://www.ebay.com/", 0),
    ("https://www.walmart.com/", 0),
    ("https://www.target.com/", 0),
    ("https://www.bestbuy.com/", 0),
    ("https://www.homedepot.com/", 0),
    ("https://www.lowes.com/", 0),
    ("https://www.costco.com/", 0),
    ("https://www.aliexpress.com/", 1),
    ("https://www.etsy.com/", 1),
    ("https://www.newegg.com/", 0),
    ("https://www.macys.com/", 0),
    ("https://www.wayfair.com/", 1),
    ("https://www.nike.com/", 0),
    ("https://www.adidas.com/", 0),
    ("https://www.samsung.com/", 0)
   
]

# Extract text content and labels from the dataset
texts = []
labels = []
for url, label in websites:
    text = extract_text_from_url(url)
    if text:
        texts.append(text)
        labels.append(label)

# Preprocess text
preprocessed_texts = [preprocess_text(text) for text in texts if text]

# Vectorize text using TF-IDF
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(preprocessed_texts)
y = labels

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a RandomForestClassifier
classifier = RandomForestClassifier()
classifier.fit(X_train, y_train)

# Make predictions on the test set
y_pred = classifier.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

# Example function to detect dark patterns in a new website
def detect_dark_patterns(url):
    text = extract_text_from_url(url)
    if text:
        preprocessed_text = preprocess_text(text)
        X_new = vectorizer.transform([preprocessed_text])
        prediction = classifier.predict(X_new)
        return bool(prediction[0])  # Convert prediction to boolean (1 -> True, 0 -> False)
    else:
        return None

# Example usage
new_url = "https://asus.com"
prediction = detect_dark_patterns(new_url)
if prediction is not None:
    if prediction:
        print("Dark patterns detected in", new_url)
    else:
        print("No dark patterns detected in", new_url)
else:
    print("Failed to fetch content from", new_url)
  