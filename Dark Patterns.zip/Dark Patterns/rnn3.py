import requests
from bs4 import BeautifulSoup
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import urllib3

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Function to extract text content from a website URL
def extract_text_from_url(url):
    try:
        response = requests.get(url, verify=False)  # Disable SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        # Extract text from HTML content
        text = ' '.join([element.get_text(separator=' ') for element in soup.find_all(['p', 'span', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'])])
        return text
    except Exception as e:
        print("Error:", e)
        return ""

# Function to preprocess text
def preprocess_text(text):
    # Implement your preprocessing steps here
    return text

# Example dataset of websites labeled with dark pattern presence (1) or absence (0)
# You should replace this with your own labeled dataset
websites = [
    ("https://www.amazon.com/", 1),
    ("https://www.ebay.com/", 0),
    ("https://www.aliexpress.com/", 1),
    ("https://www.apple.com/", 0),
    ("https://www.microsoft.com/", 0),
    ("https://www.ibm.com/", 0),
    ("https://www.oracle.com/", 0),
    ("https://www.zara.com/", 1),
    ("https://www.forever21.com/", 1),
    ("https://www.hm.com/", 1)
    # Add more websites with labels as needed
]

# Extract text content and labels from the dataset
texts = []
labels = []
for url, label in websites:
    text = extract_text_from_url(url)
    if text:
        texts.append(text)
        labels.append(label)

# Preprocess text
preprocessed_texts = [preprocess_text(text) for text in texts]

# Vectorize text using TF-IDF
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(preprocessed_texts)
y = labels

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a RandomForestClassifier
classifier = RandomForestClassifier()
classifier.fit(X_train, y_train)

# Make predictions on the test set
y_pred = classifier.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

# Example function to detect dark patterns in a new website
def detect_dark_patterns(url):
    text = extract_text_from_url(url)
    if text:
        preprocessed_text = preprocess_text(text)
        X_new = vectorizer.transform([preprocessed_text])
        prediction = classifier.predict(X_new)
        return bool(prediction[0])  # Convert prediction to boolean (1 -> True, 0 -> False)
    else:
        return None

# Example usage
new_url = "https://ebay.com"
prediction = detect_dark_patterns(new_url)
if prediction is not None:
    if prediction:
        print("Dark patterns detected in", new_url)
    else:
        print("No dark patterns detected in", new_url)
else:
    print("Failed to fetch content from", new_url)