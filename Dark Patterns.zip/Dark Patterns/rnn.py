import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.model_selection import train_test_split

# Sample data
data = pd.DataFrame({
    'URL': ['www.example.com', 'www.example.com', 'www.example.com', 'www.darkpattern.com', 'www.darkpattern.com'],
    'Interaction': ["Clicked on 'Subscribe' button", "Clicked on 'Cancel' button", "Clicked on 'Subscribe' button again", "Clicked on 'Unsubscribe' button", "Clicked on 'OK' button"],
    'IsDarkPattern': [0, 1, 0, 1, 0]  # 0 - Not a dark pattern, 1 - Dark pattern
})

# Tokenization
tokenizer = Tokenizer()
tokenizer.fit_on_texts(data['Interaction'])
sequences_tokenized = tokenizer.texts_to_sequences(data['Interaction'])

# Padding sequences
max_sequence_length = max(len(seq) for seq in sequences_tokenized)
sequences_padded = pad_sequences(sequences_tokenized, maxlen=max_sequence_length)

# Encode URLs
url_mapping = {url: i for i, url in enumerate(data['URL'].unique())}
data['Encoded_URL'] = data['URL'].map(url_mapping)

# Combine URL and sequence inputs
X = [data['Encoded_URL'].values.reshape(-1, 1), sequences_padded]
y = data['IsDarkPattern'].values

# Splitting data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Build the RNN model
input_url = tf.keras.Input(shape=(1,))
input_sequence = tf.keras.Input(shape=(max_sequence_length,))
embedding_url = tf.keras.layers.Embedding(input_dim=len(data['URL'].unique()), output_dim=64)(input_url)
embedding_sequence = tf.keras.layers.Embedding(input_dim=len(tokenizer.word_index) + 1, output_dim=64, input_length=max_sequence_length)(input_sequence)
lstm_sequence = tf.keras.layers.LSTM(64)(embedding_sequence)
concatenated = tf.keras.layers.concatenate([embedding_url, lstm_sequence])
output = tf.keras.layers.Dense(1, activation='sigmoid')(concatenated)

model = tf.keras.Model(inputs=[input_url, input_sequence], outputs=output)

model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

# Train the model
model.fit(X_train, y_train, epochs=10, batch_size=1)

# Evaluate the model
loss, accuracy = model.evaluate(X_test, y_test)
print(f"Test Loss: {loss}, Test Accuracy: {accuracy}")

# Now you can use this model to predict whether new interactions contain dark patterns or not
